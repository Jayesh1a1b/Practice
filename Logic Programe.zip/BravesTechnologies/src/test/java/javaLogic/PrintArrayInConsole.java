package javaLogic;

import java.util.Arrays;

public class PrintArrayInConsole {

	public static void main(String[] args) {
		int a[]= {10,20,30,40,50};
		System.out.println(Arrays.toString(a));

	}

}
