package javaLogic;

public class AsciiValue {

	public static void main(String[] args) {
		char ch='A';// given input in character and return type is character
       int a1='A';
       System.out.println(a1);
       
       char ch1='a';
       int a2 ='a';
       System.out.println(a2);
	}

}
