package javaLogic;

public class FactorOfNumber {

	public static void main(String[] args) {
		int n=5;
		int factorial=1;
		for(int i=1;i<=n;i++)
		{
			factorial=factorial*i;//5*2=10*3=30*4=120
		}
		System.out.println(factorial);

	}

}
