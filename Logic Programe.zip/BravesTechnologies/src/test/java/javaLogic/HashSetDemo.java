package javaLogic;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet hs=new HashSet();
		hs.add("pune");
		hs.add("100");
		hs.add("true");
		hs.add("pune");
		System.out.println(hs);
	}

}
