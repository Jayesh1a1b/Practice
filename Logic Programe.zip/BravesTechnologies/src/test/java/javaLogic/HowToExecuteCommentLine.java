package javaLogic;

public class HowToExecuteCommentLine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub \u000d System.out.println("jayesh");
//\u000d 
		
	}

}
