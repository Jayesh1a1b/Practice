package javaLogic;

public class FactorOfAnyNumber {

	public static void main(String[] args) {
		//factor=1,2,5,10
	int a=10;
	for(int i=1;i<=a;i++)
	{
		if(a%i==0)
		{
			System.out.println(i);
		}
	}

	}

}
