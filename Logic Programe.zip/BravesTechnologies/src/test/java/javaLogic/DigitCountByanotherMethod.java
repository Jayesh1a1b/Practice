package javaLogic;

public class DigitCountByanotherMethod {

	public static void main(String[] args) {
		int n=12345;
		String str = Integer.toString(n);//convert int to String
		int digit = str.length();
		System.out.println(digit);

	}

}
