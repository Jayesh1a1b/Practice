package javaLogic;

public class SwapNumber {

	public static void main(String[] args) {
		int a=10;int b=20;
		int temp;
		System.out.println("Before swapping values of a and b is "+a+" "+b);
		temp=a;//10
		a=b;//20
		b=temp;//10
		System.out.println("After swapping values of a and b is "+a+" "+b);

	}

}
